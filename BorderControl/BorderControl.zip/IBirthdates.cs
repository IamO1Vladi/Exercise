﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    internal interface IBirthdates
    {
        public string BirthDate { get; }
    }
}
