﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    internal interface IPhone
    {

        public void CallNumber(string number);
    }
}
